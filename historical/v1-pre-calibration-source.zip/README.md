# Qwen3.8-27B Context Cache Experiment (Draft)

这是第二篇独立实验的离线工程草案，研究阿里云百炼 `qwen3.8-27b` 在长公共前缀下的冷请求、隐式缓存和显式缓存表现。

当前状态：**pre-live draft，尚未冻结，真实 API 请求数为 0。**

## 研究设计概览

- 模型：`qwen3.8-27b`
- 地域：华北 2（北京）
- 接口：OpenAI-compatible Chat Completions
- Thinking：关闭
- 温度：0
- 长度档位：目标约 2K / 6K / 10K 输入 Token；离线按字符规模预校准，最终以 API `prompt_tokens` 为准
- 策略：A 冷请求基线、B 隐式缓存、C 显式缓存
- 2 份独立合成文档，每条链 3 个顺序请求
- 正式规模：`3 × 3 × 2 × 3 = 54` 个 observation
- 预检：最多 6 个 observation
- 不自动重试；任何 HTTP 错误保留为失败 observation

## 当前可做的离线工作

```powershell
python -m pytest
python -m src.execution_plan --seed 20260906 --output plans/execution_order.draft.json
```

运行真实请求前必须完成人工审计、把 `DRAFT_PREREGISTRATION.md` 转为冻结版本，并显式启用 live gate。不要把 API Key 写入源码或提交到仓库。

## 重要术语

A 只能称为“冷请求基线”，不能称为“关闭缓存”。百炼隐式缓存无法关闭；A 使用等长、语义无关、每次唯一的请求标识破坏公共前缀复用。

B 与 C 的提示文本逐字节一致；C 只额外携带 API 的 `cache_control` 元数据。A 的 nonce 与 B/C 等字符长度，但内容必须不同才能破坏前缀复用。正式分析使用 API 实际 `prompt_tokens`，不假设等字符必然等 Token。

`thinking_budget` 不参与本实验。所有条件统一关闭 Thinking，以隔离缓存因素。
